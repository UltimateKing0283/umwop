![screenshot](./img/ss1.png)
![screenshot](./img/ss2.png)
![screenshot](./img/ss3.png)

# Free Discord Bot Website Template
### Today i make a `Discord Bot Website Template` for free (landing page only).

# Installation
### nodejs are not required for this project.
#### 1. clone this project to your pc/laptop
#### 2. open index.html on browser, tada!!! you can change that all on website :)
#### 2. IMPORTANT: star this repo for more project

# Tutorial video
### [click me](https://www.youtube.com/watch?v=l1aKSgvgbmc)

# Note: if this repo reach 100 stars, i will make full page
# But you can buy the full page if you doesnt want to waiting
# DM me on instagram: @Vins2106

# Make by Vins 2106 with html, css, js 
